<?php
require('code128.php');
require_once("phpqrcode/qrlib.php");
$pdf=new PDF_Code128('L','mm',array(50.8,76.52));
$pdf->SetFont('Arial','',8);	
$pdf->SetMargins(1, 0, 0);
$pdf->SetAutoPageBreak(false);
print_label($pdf);
$pdf->Output();

function print_label($pdf) {

    $pdf->AddPage();
    $code="1234567890";

    $pdf->SetFont('Arial','B',7);

    $pdf->Ln(1);
    $pdf->SetFillColor(0, 0, 0);
    $pdf->SetTextColor(255,255, 255);
    $pdf->Cell(74,5,"SILGAN WHITECAP",0,0,'C',1);  
    $pdf->SetTextColor(0);
    $pdf->SetFillColor(255);    
    $pdf->Ln(6);
    $pdf->Cell(74,3,"ITEM CODE :",0,0,'L');  
    $pdf->Ln(4);
    $pdf->Cell(74,3,"DESCRIPTION :",0,0,'L');  
    $pdf->Ln(8);
    $pdf->Cell(74,3,"COIL/BATCH# :",0,0,'L');  
    $pdf->Ln(4);
    $pdf->Cell(74,3,"MFG. DATE :",0,0,'L');  
    $pdf->Ln(4);
    $pdf->Cell(74,3,"EXP. DATE :",0,0,'L');  
    $pdf->Ln(4);
    $pdf->Cell(74,3,"QUANTITY :",0,0,'L');  
    $pdf->Ln(4);
    $pdf->Cell(74,3,"UOM :",0,0,'L');  
    $pdf->Ln(4);
    $pdf->Cell(74,3,"NET WT. :",0,0,'L');  
    $pdf->Ln(4);
    $pdf->Cell(74,3,"GROSS WT. :",0,0,'L'); 
    $pdf->Ln(4);
    $pdf->Cell(74,3,"SUPPLIER :",0,0,'L'); 
    QRcode::png($code,"pdf/".$code.".png");
    $pdf->Image("pdf/".$code.".png", 47, 20, 27, 27, "png");

 }


?>